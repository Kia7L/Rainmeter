    
[RECOIL7L:](0x11111111){
Filter
{
	"Height" "1"
	"Width" "1"
	"FilterType" "FILTER_ADD"
	"IconName" "Add1x1.ico"
	Image
	{
		"row0" "1.0"
	}
}

Filter
{
	"Height" "3"
	"Width" "3"
	"FilterType" "FILTER_ADD"
	"IconName" "Add2x2.ico"
	Image
	{
		"row0" "0.0 0.5 0.0"
		"row1" "0.5 1.0 0.5"
               	"row2" "0.0 0.5 0.0"
	}
}

Filter
{
	"Height" "5"
	"Width" "5"
	"FilterType" "FILTER_ADD"
	"IconName" "Add3x3.ico"
	Image
	{
		"row0" "0.0  0.0  0.25 0.0  0.0"
		"row1" "0.0  0.25 0.5  0.25 0.0"
               	"row2" "0.25 0.5  1.0  0.5  0.25"
		"row3" "0.0  0.25 0.5  0.25 0.0"
		"row4" "0.0  0.0  0.25 0.0  0.0"
	}
}

Filter
{
	"Height" "7"
	"Width" "7"
	"FilterType" "FILTER_ADD"
	"IconName" "Add4x4.ico"
	Image
	{
		"row0" "0.0   0.0   0.0   0.125 0.0   0.0   0.0"
		"row1" "0.0   0.0   0.125 0.25  0.125 0.0   0.0"
               	"row2" "0.0   0.125 0.25  0.5   0.25  0.125 0.0"
		"row3" "0.125 0.25  0.5   1.0   0.5   0.25  0.125"
		"row4" "0.0   0.125 0.25  0.5   0.25  0.125 0.0"
		"row5" "0.0   0.0   0.125 0.25  0.125 0.0   0.0"
		"row6" "0.0   0.0   0.0   0.125 0.0   0.0   0.0"
	}
}
             
Filter
{
	"Height" "1"
	"Width" "1"
	"FilterType" "FILTER_EQUAL"
	"IconName" "Flat1x1.ico"
	Image
	{
		"row0" "0.0"
	}
}

Filter
{
	"Height" "3"
	"Width" "3"
	"FilterType" "FILTER_EQUAL"
	"IconName" "Flat2x2.ico"
	Image
	{
		"row0" "-99999.0 0.0 -99999.0"
		"row1" "0.0      0.0 0.0"
		"row2" "-99999.0 0.0 -99999.0"
	}
}

Filter
{
	"Height" "5"
	"Width" "5"
	"FilterType" "FILTER_EQUAL"
	"IconName" "Flat3x3.ico"
	Image
	{
		"row0" "-99999.0 -99999.0 0.0 -99999.0 -99999.0"
		"row1" "-99999.0 0.0      0.0 0.0      -99999.0"
		"row2" "0.0      0.0      0.0 0.0      0.0"
		"row3" "-99999.0 0.0      0.0 0.0      -99999.0"
		"row4" "-99999.0 -99999.0 0.0 -99999.0 -99999.0"
	}
}

Filter
{
	"Height" "3"
	"Width" "3"
	"FilterType" "FILTER_CONVATTEN"
	"IconName" "Smooth2x2.ico"
	Image
	{
		"row0" "0.25 0.5 0.25"
		"row1" "0.5  1.0 0.5"
		"row2" "0.25 0.5 0.25"
	}
}

Filter
{
	"Height" "5"
	"Width" "5"
	"FilterType" "FILTER_EQUAL"
	"IconName" "RaiseTo1x1.ico"
	Image
	{
		"row0" "-99999.0 -99999.0 -99999.0 -99999.0 -99999.0"
		"row1" "-99999.0 -99999.0 -99999.0 -99999.0 -99999.0"
		"row2" "-99999.0 -99999.0      1.0 -99999.0 -99999.0"
		"row3" "-99999.0 -99999.0 -99999.0 -99999.0 -99999.0"
		"row4" "-99999.0 -99999.0 -99999.0 -99999.0 -99999.0"
	}
}


Filter
{
	"Height" "5"
	"Width" "5"
	"FilterType" "FILTER_EQUAL"
	"IconName" "RaiseTo3x3.ico"
	Image
	{
		"row0" "-99999.0 -99999.0 1.0 -99999.0 -99999.0"
		"row1" "-99999.0 1.0      1.0 1.0      -99999.0"
		"row2" "1.0      1.0      1.0 1.0      1.0"
		"row3" "-99999.0 1.0      1.0 1.0      -99999.0"
		"row4" "-99999.0 -99999.0 1.0 -99999.0 -99999.0"
	}
}

    }