/*---------------------------------------------*/
/*-Collider-*/
float 4 A1=<.vtf>(*)<.vtf>;
float 4 A2=<.obj>(*)<.obj>;
float 4 A3=<.vtm>(*)<.vtm>;
float 4 A4=<.blen>(*)<.blen>;
float 4 A5=<.skp>(*)<.skp>;
float 4 A6=<.dae>(*)<.dae>;
float 4 A7=<.>(*)<.>;
float 4 A8=<*.*>(*)<*.*>;
float 4 A9=<~.~>(*)<~.~>;
float 4 B1=0x01(*)0x01;
float 4 B2=0x02(*)0x02;
[Damage]B2=(-2,2):Delay(11,0);
/*---------------------------------------------*/