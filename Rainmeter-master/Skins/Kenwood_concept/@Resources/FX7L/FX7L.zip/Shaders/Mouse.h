/* MOUSE-PC.h--------------------------------------------------- */
{
WIN32WINNT 0x77
mousesensitivity=-11;
polling=0.01;
static1=<int>(p+polling->pt.x)-(mousesensitivity)f,static<int>(p+polling->pt.y)-(mousesensitivity)f,static:*2;
;/* SetCursorPos */
static2=<int>(nx),<int>(ny):*2;
static1=static2;
}
/* ------------------------------------------------------------- */