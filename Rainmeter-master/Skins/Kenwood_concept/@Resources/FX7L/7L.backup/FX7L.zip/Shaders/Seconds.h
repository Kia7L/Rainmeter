/*-60seconds-*/
[60000ms:]
(1min:60sec)=(1min:60000ms);
	