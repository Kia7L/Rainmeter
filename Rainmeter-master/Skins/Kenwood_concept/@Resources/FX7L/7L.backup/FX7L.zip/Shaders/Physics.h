/*-Physics------------------------------------*/
{
float 0x00
float Download=(-200(<-)-72);/*cd-R.Download*/
float Loading=(0.2(<-)0.8);/*Compensator*/
<avgtimeperwindow=(Download)/>;
<avgtimeperframe=(Loading)/>;
[Catche:] 0x02:Download(-200(<->)-2);
}
/*---------------------------------------------*/