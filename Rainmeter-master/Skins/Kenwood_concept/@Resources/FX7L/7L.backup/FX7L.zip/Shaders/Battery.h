/*-Skyn3t-ArtifitialIntelegence-*/	
[Battery:]
[Battery](100->2|2<-100);
/*---------------------------------------------*/